/* Maison Milia theme: menu, cart drawer (AJAX cart), product options, gallery, size guide, motion. */
(function () {
  "use strict";
  var $ = function (id) { return document.getElementById(id); };
  var $$ = function (s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); };
  var MM = window.MM || { root: "/", freeShip: 8000 };
  var root = MM.root.slice(-1) === "/" ? MM.root : MM.root + "/";
  var reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  var money = function (cents) { return (cents / 100).toLocaleString("fr-FR", { style: "currency", currency: MM.currency || "EUR" }); };

  /* ---------- Mobile menu ---------- */
  var menuBtn = $("menu-btn");
  if (menuBtn) menuBtn.addEventListener("click", function () {
    var n = $("mobile-nav"), open = n.hidden;
    n.hidden = !open; menuBtn.setAttribute("aria-expanded", String(open));
  });

  /* ---------- Size guide + cookie preferences ---------- */
  var sg = $("sg");
  document.addEventListener("click", function (e) {
    if (e.target.closest("[data-size-guide]") && sg) { e.preventDefault(); sg.showModal(); }
    if (e.target.closest("[data-close]")) { var d = e.target.closest("dialog"); if (d) d.close(); }
    if (e.target.closest("[data-cookie-open]") && window.privacyBanner) { window.privacyBanner.showPreferences(); }
  });
  if (sg) sg.addEventListener("click", function (e) { if (e.target === sg) sg.close(); });

  /* ---------- Cart drawer ---------- */
  var drawer = $("cart"), scrim = $("scrim"), opener = $("cart-open");
  function fetchJSON(url, opts) {
    return fetch(url, opts).then(function (r) { return r.json().then(function (j) { if (!r.ok) throw j; return j; }); });
  }
  function renderCart(cart) {
    var count = cart.item_count, sub = cart.total_price;
    var c = $("cart-count"); if (c) { c.textContent = count; c.setAttribute("data-empty", String(count === 0)); }
    $("cart-total").textContent = money(sub);
    $("checkout").hidden = count === 0;
    var left = Math.max(0, MM.freeShip - sub);
    $("ship-text").textContent = left > 0 ? "Plus que " + money(left) + " pour la livraison offerte." : "Livraison offerte.";
    $("ship-fill").style.width = Math.min(100, sub / MM.freeShip * 100) + "%";
    var lines = $("cart-lines");
    lines.innerHTML = "";
    if (!cart.items.length) {
      lines.innerHTML = '<li class="empty">Ton panier est vide. <a class="textlink" href="' + root + 'collections/all">Voir la collection</a></li>';
      return;
    }
    cart.items.forEach(function (it, i) {
      var li = document.createElement("li"); li.className = "line";
      li.innerHTML = '<img alt=""><div><p class="name"></p><p class="meta"></p><div class="qty"><button type="button" data-d="-1">−</button><output></output><button type="button" data-d="1">+</button></div></div><span class="price"></span>';
      var img = li.querySelector("img");
      if (it.image) img.src = it.image + (it.image.indexOf("?") > -1 ? "&" : "?") + "width=200"; else img.remove();
      li.querySelector(".name").textContent = it.product_title;
      li.querySelector(".meta").textContent = (it.variant_title ? it.variant_title + ". " : "") + "Précommande" + (MM.shipDate ? ", expédition " + MM.shipDate : "") + ".";
      li.querySelector("output").textContent = it.quantity;
      li.querySelector(".price").textContent = money(it.final_line_price);
      var minus = li.querySelector('[data-d="-1"]'), plus = li.querySelector('[data-d="1"]');
      minus.setAttribute("aria-label", (it.quantity === 1 ? "Retirer " : "Diminuer la quantité de ") + it.product_title);
      plus.setAttribute("aria-label", "Augmenter la quantité de " + it.product_title);
      minus.addEventListener("click", function () { changeLine(i + 1, it.quantity - 1); });
      plus.addEventListener("click", function () { changeLine(i + 1, it.quantity + 1); });
      lines.appendChild(li);
    });
  }
  function refreshCart() { return fetchJSON(root + "cart.js").then(renderCart); }
  function changeLine(line, qty) {
    return fetchJSON(root + "cart/change.js", { method: "POST", headers: { "Content-Type": "application/json", Accept: "application/json" }, body: JSON.stringify({ line: line, quantity: Math.max(0, qty) }) })
      .then(renderCart).then(function () { $("cart-close").focus(); });
  }
  function openCart() {
    drawer.classList.add("open"); scrim.classList.add("open"); drawer.setAttribute("aria-hidden", "false");
    if (opener) opener.setAttribute("aria-expanded", "true");
    $("cart-close").focus();
  }
  function closeCart() {
    drawer.classList.remove("open"); scrim.classList.remove("open"); drawer.setAttribute("aria-hidden", "true");
    if (opener) { opener.setAttribute("aria-expanded", "false"); opener.focus(); }
  }
  if (drawer) {
    if (opener) opener.addEventListener("click", function (e) { e.preventDefault(); refreshCart().then(openCart); });
    $("cart-close").addEventListener("click", closeCart);
    scrim.addEventListener("click", closeCart);
    document.addEventListener("keydown", function (e) { if (e.key === "Escape" && drawer.classList.contains("open")) closeCart(); });
    refreshCart().catch(function () {});
  }

  /* ---------- Product page ---------- */
  var buy = $("buy"), pdp = document.querySelector("[data-product]");
  if (buy && pdp) {
    var variants = JSON.parse(buy.querySelector("[data-variants]").textContent);
    var sizeIndex = pdp.dataset.sizeIndex === "" ? -1 : Number(pdp.dataset.sizeIndex);
    var colourIndex = pdp.dataset.colourIndex === "" ? -1 : Number(pdp.dataset.colourIndex);
    var idInput = buy.querySelector("[data-variant-id]");
    var stage = $("stage"), stageImg = $("stage-img"), thumbs = $$("#thumbs button");

    function selected() {
      var opts = [];
      $$("[data-option]:checked", buy).forEach(function (i) { opts[Number(i.dataset.option)] = i.value; });
      return opts;
    }
    function findVariant(opts) {
      return variants.filter(function (v) { return v.options.every(function (o, k) { return opts[k] === undefined || opts[k] === o; }); })[0];
    }
    function setStage(btn) {
      if (!btn || !stageImg) return;
      thumbs.forEach(function (b) { b.setAttribute("aria-pressed", String(b === btn)); });
      stageImg.src = btn.dataset.src; stageImg.alt = btn.dataset.alt;
      stageImg.classList.toggle("contain", btn.dataset.contain === "1");
    }
    function filterThumbs(colour) {
      if (!colour || thumbs.length < 2) return;
      var key = colour.toLowerCase(), match = thumbs.filter(function (b) { return b.dataset.key.indexOf(key) > -1; });
      if (!match.length) { thumbs.forEach(function (b) { b.hidden = false; }); return; }
      thumbs.forEach(function (b) { b.hidden = match.indexOf(b) < 0; });
      setStage(match[0]);
    }
    function update() {
      var opts = selected(), v = findVariant(opts);
      if (v) {
        idInput.value = v.id;
        $$("[data-price]", buy).forEach(function (el) { el.textContent = money(v.price); });
        if (v.featured_media && !(colourIndex > -1)) {
          var b = thumbs.filter(function (t) { return t.dataset.src.indexOf(v.featured_media.preview_image.src.split("?")[0].split("/").pop().split(".")[0]) > -1; })[0];
          if (b) setStage(b);
        }
      }
      if (colourIndex > -1) {
        var lab = buy.querySelector('[data-option-label="' + colourIndex + '"]'); if (lab && opts[colourIndex]) lab.textContent = opts[colourIndex];
        filterThumbs(opts[colourIndex]);
      }
    }
    buy.addEventListener("change", function (e) { if (e.target.dataset.option !== undefined) { $("buy-err").hidden = true; update(); } });
    thumbs.forEach(function (b) { b.addEventListener("click", function () { setStage(b); }); });
    update();

    if (stage && stageImg) {
      stage.addEventListener("pointermove", function (e) { var r = stage.getBoundingClientRect(); stage.style.setProperty("--zx", ((e.clientX - r.left) / r.width * 100) + "%"); stage.style.setProperty("--zy", ((e.clientY - r.top) / r.height * 100) + "%"); });
      stage.addEventListener("pointerenter", function (e) { if (e.pointerType === "mouse") stage.classList.add("zoom"); });
      stage.addEventListener("pointerleave", function () { stage.classList.remove("zoom"); });
      stage.addEventListener("click", function () { stage.classList.toggle("zoom"); });
    }

    buy.addEventListener("submit", function (e) {
      e.preventDefault();
      var err = $("buy-err");
      if (sizeIndex > -1 && !buy.querySelector('[data-option="' + sizeIndex + '"]:checked')) {
        err.hidden = false; var first = buy.querySelector('[data-option="' + sizeIndex + '"]'); if (first) first.focus(); return;
      }
      var opts = selected(), v = findVariant(opts);
      if (!v) { err.textContent = "Cette combinaison n'existe pas."; err.hidden = false; return; }
      err.hidden = true;
      var btn = buy.querySelector("[data-add]"); btn.setAttribute("aria-busy", "true");
      fetchJSON(root + "cart/add.js", { method: "POST", headers: { "Content-Type": "application/json", Accept: "application/json" }, body: JSON.stringify({ items: [{ id: v.id, quantity: 1 }] }) })
        .then(refreshCart).then(function () {
          var c = $("cart-count"); if (c) { c.classList.add("bump"); setTimeout(function () { c.classList.remove("bump"); }, 300); }
          if (drawer) openCart(); else location.href = root + "cart";
        })
        .catch(function (x) { err.textContent = (x && x.description) || "Impossible d'ajouter au panier. Réessaie."; err.hidden = false; })
        .then(function () { btn.removeAttribute("aria-busy"); });
    });
  }

  /* ---------- Collection: sorting submits the filter form ---------- */
  var sort = document.querySelector("[data-sort]"), filters = $("filters");
  if (sort && filters) sort.addEventListener("change", function () { filters.querySelector('[name="sort_by"]').value = sort.value; filters.submit(); });
  if (filters) filters.addEventListener("change", function (e) { if (e.target.type === "checkbox") filters.submit(); });

  /* ---------- Lookbook arrows ---------- */
  $$(".look").forEach(function (look) {
    var sec = look.closest("section");
    $$("[data-look]", sec).forEach(function (b) { b.addEventListener("click", function () { look.scrollBy({ left: Number(b.dataset.look) * look.clientWidth * 0.8, behavior: reduced ? "auto" : "smooth" }); }); });
  });

  /* ---------- Motion ---------- */
  if (!reduced && "IntersectionObserver" in window) {
    document.documentElement.classList.add("js-motion");
    var i = 0;
    $$("[data-split]").forEach(function (el) {
      var t = el.textContent; el.textContent = "";
      t.split("").forEach(function (c) { var s = document.createElement("span"); s.className = "ch"; s.setAttribute("aria-hidden", "true"); s.style.setProperty("--i", i++); s.textContent = c; el.appendChild(s); });
    });
    var io = new IntersectionObserver(function (es) { es.forEach(function (e) { if (e.isIntersecting) { e.target.classList.add("in"); io.unobserve(e.target); } }); }, { rootMargin: "0px 0px -8% 0px" });
    $$(".reveal").forEach(function (el) { io.observe(el); });
    document.addEventListener("shopify:section:load", function (e) { $$(".reveal", e.target).forEach(function (el) { el.classList.add("in"); }); });
  }
})();
